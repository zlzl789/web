from django import forms

class PersonForm(forms.Form):
    title = forms.CharField(label='URL', max_length=300)

class Key(forms.Form):
    keyword = forms.CharField(label ='NAVER', max_length=300)

class Key1(forms.Form):
    keyword1 = forms.CharField(label='Daum', max_length=300)

class Key2(forms.Form):
    keyword2 = forms.CharField(label='N', max_length=300)

class Key3(forms.Form):
    keyword3 = forms.CharField(label='D', max_length=300)
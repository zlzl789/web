from django.shortcuts import render
from django.db import connection
import requests
from bs4 import BeautifulSoup

from .forms import PersonForm
from .forms import Key
from .forms import Key1
from .forms import Key2
from .forms import Key3


def index(request):
    return render(request, 'hello_app/main.html')


def urls(request):

    if request.method == 'POST':
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36 Edge/14.14393'}

        form = PersonForm(request.POST)
        url = form.data['title']
        req = requests.get(url, headers=headers).text
        posts = []

        cursor = connection.cursor()
        query_string = "select * from topic"
        cursor.execute(query_string)
        se = cursor.fetchall()

        for ti in se:
            if ti[2] in req:
                dic = {'site': ti[1], 'url': ti[2]}
                posts.append(dic)

        if form.is_valid():  # 폼 검증
            return render(request, 'hello_app/urls.html', {'form': form, 'posts':posts,'url':url})

    else:
        form = PersonForm()  # forms.py의 PostForm 클래스의 인스턴스
        return render(request, 'hello_app/urls.html', {'form': form})  # 템플릿 파일 경로 지정, 데이터 전달








def key(request):  # key 라는 함수(그룹) 만들겠다고 def로 선언했어

    post = []  # 데이터베이스 안의 내용들이 한번씩 돌때마다 쌓여 담겨있어요 (포문안에쓰면 리셋되어 마지막꺼만 나옴)

    if request.method == 'POST':  # 포스트로 받은 값이 있다면
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36 Edge/14.14393'}

        forms = Key(request.POST)  # HTTP가 인식하는 포스트의 모든값
        ke = forms.data['keyword']  # POST안에 있는 키 값
        url = 'https://ad.search.naver.com/search.naver?where=ad&sm=svc_nrs&query={}'.format(ke)  # 네이버 파워링크 url 뒤로 키워드값 넣기
        uurl = url + '&pagingIndex={}'  # 페이지 수


        for n in range(1, 20):  # url페이지 수 100번 돌리기 포문
            u_url = uurl.format(n)  # url페이지 수 뒤로 n번만큼(100) 돌려라
            print(u_url)
            reqe = requests.get(u_url, headers=headers).text  # 키워드넣은 값의 url을 갖고왔다
            soup = BeautifulSoup(reqe, 'lxml', from_encoding='utf-8')  # url을 뷰티풀소프로 컴퓨터가 읽을수있는 html파일로 쪄버리기
            titles_by_select = soup.select('ol.lst_type > li') # a태그 선택하여 titles_by_select안에 담아요
            if not titles_by_select:  # a태그가 없으면(값) 멈춰라
                break



            for titl in titles_by_select:  # titles_by_select안에 titl가 있는동안 도라라
                link = titl.find('a',{'class':'lnk_tit'})
                link_r = link.get('href')
                te = link.text  # te안에 titl을 텍스트인것들(쇼핑몰 이름)을 담아라! 잘 담김=프린트해봄
                link2 = titl.find('a',{'class':'sub_tit'})


                if link2:
                    link2_r = link2.get('href') #두번째 타이틀의 주소
                    te2 = link2.text #두번째 타이틀
                else:
                    te2 = ""
                    link2_r=""


                img = titl.find('img',{'class':'image'})
                if  img:
                    iimg = img.get('src')#이미지가 있을 시 src뒤로붙은 주소가져오기
                else:
                    iimg = "None"

                url_r = titl.find('a', {'class': 'url'})
                f_url = url_r.get('href')


                try:
                    f_req = requests.get(f_url, headers=headers).text
                    s_url = url_r.text # 화면의 나오는 url



                    p_title = titl.find_all('p', 'ad_dsc')
                    if  p_title:
                        p_text = p_title[0].text
                    else:
                        p_text= ""

                    p_title2 = titl.find('em',{'class':'point'})
                    if  p_title2:
                        ret = titl.find_all('p', 'promotion')
                        p_title = titl.find_all('p', 'ad_dsc')
                        p_text = p_title[1].text
                        p_text2 = ret[0].text

                    else:
                        p_text2 = ""


                    po = []
                    item = titl.find('ul',{'class':'lst_link'})
                    if item:
                        re = item.find_all('a','link')
                        for i1 in re:
                            re1 = i1.text
                            re11 = i1.get('href')

                            du = {'url':re11,'tit':re1}
                            po.append(du)
                    else:
                        po = ""



                    pi = []
                    item2 = titl.find('ul',{'class':'lst_price'})
                    if item2:
                        re2 = item2.find_all('a','link')
                        for i2 in re2:
                            re2 = i2.text
                            ree = i2.get('href')

                            d = {'url_1':ree,'tit_1':re2}
                            pi.append(d)
                    else:
                        pi = ""



                    il = titl.find_all('em','txt')
                    ir = il[0].text #광고집행기간

                    cur = connection.cursor()
                    string = "select * from topic"
                    cur.execute(string)
                    see = cur.fetchall()

                    post1 = []
                    for t in see:  # 데이터베이스와 url 비교하는구문
                        if t[2] in f_req:
                            di = t[1]
                            post1.append(di)

                        dd = {'img':iimg,'site': te, 'site2':te2 ,'f_url':f_url , 'te':ir, 'p':p_text,'p_text2':p_text2, 'title': post1, 'link_k':link_r,'link2_r':link2_r,'s_url':s_url,'po':po,'pi':pi}
                except:
                    dd = {'img': iimg, 'site': te, 'site2': te2, 'f_url': f_url, 'te': ir, 'p': p_text,
                          'p_text2': p_text2, 'title': "사이트 접속오류", 'link_k': link_r, 'link2_r': link2_r, 's_url': s_url,
                          'po': po, 'pi': pi}
                    pass


                post.append(dd)




        if forms.is_valid():  # 폼 검증 #얘는 if request.method == 'POST': 안에 있어야 함
            return render(request, 'hello_app/key.html', {'form': forms, 'post': post})


    else:  # 얘는 if request.method == 'POST': 얘랑 짝꿍이라 if request.method == 'POST':쟤 줄에 같이있어야한다
        forms = Key()
        return render(request, 'hello_app/key.html', {'form': forms, })  # 템플릿 파일 경로 지정, 데이터 전달






def d_key(request):
    post = []  # 데이터베이스 안의 내용들이 한번씩 돌때마다 쌓여 담겨있어요 (포문안에쓰면 리셋되어 마지막꺼만 나옴)
    if request.method == 'POST':  # 포스트로 받은 값이 있다면
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36 Edge/14.14393'}

        forms = Key1(request.POST)  # HTTP가 인식하는 포스트의 모든값
        ke = forms.data['keyword1']  # POST안에 있는 키 값
        url = 'http://search.daum.net/search?w=ad&q={}'.format(ke)  # 네이버 파워링크 url 뒤로 키워드값 넣기
        uurl = url + '&p={}'  # 페이지 수
        req = requests.get(url, headers=headers)  # 키워드넣은 값의 url을 갖고왔다
        html = req.text
        soup = BeautifulSoup(html, 'lxml')
        total = soup.select('body.daum')

        for at in total:
            art = at.text
            r = art.split('totalCount:')[1]
            d = r[1]+r[2]

            dew=int(d)
            gr = dew/20
            result = round(gr+1)

        for n in range(1,result):  # url페이지 수 100번 돌리기 포문

            u_url = uurl.format(n)  # url페이지 수 뒤로 n번만큼(100) 돌려라
            reqe = requests.get(u_url, headers=headers)  # 키워드넣은 값의 url을 갖고왔다

            html2 = reqe.text
            soup2 = BeautifulSoup(html2, 'lxml')
            titles_by_select = soup2.select(' div.coll_cont > div.mg_cont > ul.list_info > li')  # a태그 선택하여 titles_by_select안에 담아요


            for titl in titles_by_select:  # titles_by_select안에 titl가 있는동안 도라라
                link = titl.find('a',{'class':'f_link_bu'})
                te = link.text #이름
                f_url = link.get('href') #주소

                si = []
                link_2 = titl.find_all('a','f_link')
                if link_2:
                    for i in link_2:
                        te_2 = i.text #이름
                        te_url = i.get('href') #주소
                        ei = {'url':te_url,'tt':te_2}
                        si.append(ei)
                else:
                    si=""

                mid = titl.find('p',{'class':'desc'})
                if mid:
                    mid_text = mid.text

                else:
                    mid_text = ""



                info = titl.find('a',{'class':'f_url'})
                if info:
                    info_text = info.text
                    info_url = info.get('href')

                else:
                    info_text = ""
                    info_url = ""


                kakao = titl.find('span',{'class':'ico_rwd ico_kakao'})
                if kakao:
                    kakao_t = kakao.text
                else:
                    kakao_t = ""


                kakaopay = titl.find('span',{'class':'ico_rwd ico_pay'})
                if kakaopay:
                    kakao_p = kakaopay.text
                else:
                    kakao_p = ""



                st = []
                link_3 = titl.find_all('a','link_etc')

                if link_3:
                    for i in link_3:

                        te_3 = i.text #이름
                        te_url3 = i.get('href') #주소
                        ei3 = {'url':te_url3,'tt':te_3}
                        st.append(ei3)
                else:
                    st=""


                img = titl.find('img',{'class':'thumb_img'})
                if  img:
                    iimg = img.get('src')#이미지가 있을 시 src뒤로붙은 주소가져오기
                else:
                    iimg = "None"



                try:
                    f_req = requests.get(f_url, headers=headers).text  #
                    cur = connection.cursor()
                    string = "select * from topic"
                    cur.execute(string)
                    see = cur.fetchall()
                    post1 = []
                    for t in see:  # 데이터베이스와 url 비교하는구문
                        if t[2] in f_req:
                            di = t[1]
                            post1.append(di) #

                        dd = {'site': te, 'title': post1, 'url': f_url,'si':si,'mid_text':mid_text,'st':st,'info_text':info_text,'info_url':info_url,'iimg':iimg,'kakao_t':kakao_t,'kakao_p':kakao_p}
                except:
                    dd = {'site': te, 'title': '사이트 접속오류', 'url': f_url, 'si': si, 'mid_text': mid_text, 'st': st,
                          'info_text': info_text, 'info_url': info_url, 'iimg': iimg, 'kakao_t': kakao_t,
                          'kakao_p': kakao_p}

                    pass




                post.append(dd)

        if forms.is_valid():  # 폼 검증 #얘는 if request.method == 'POST': 안에 있어야 함
            return render(request, 'hello_app/d_key.html', {'form': forms, 'post': post})

    else:  # 얘는 if request.method == 'POST': 얘랑 짝꿍이라 if request.method == 'POST':쟤 줄에 같이있어야한다
        forms = Key1()
        return render(request, 'hello_app/d_key.html', {'form': forms, })  # 템플릿 파일 경로 지정, 데이터 전달






def key2(request):  # key 라는 함수(그룹) 만들겠다고 def로 선언했어

    post = []  # 데이터베이스 안의 내용들이 한번씩 돌때마다 쌓여 담겨있어요 (포문안에쓰면 리셋되어 마지막꺼만 나옴)

    if request.method == 'POST':  # 포스트로 받은 값이 있다면
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36 Edge/14.14393'}

        forms = Key2(request.POST)  # HTTP가 인식하는 포스트의 모든값
        ke = forms.data['keyword2']  # POST안에 있는 키 값
        url = 'https://m.ad.search.naver.com/search.naver?where=m_expd&query={}'.format(ke)  # 네이버 파워링크 url 뒤로 키워드값 넣기

        for n in range(1, 2):  # url페이지 수 100번 돌리기 포문

            reqe = requests.get(url, headers=headers).text  # 키워드넣은 값의 url을 갖고왔다
            soup = BeautifulSoup(reqe, 'lxml', from_encoding='utf-8')  # url을 뷰티풀소프로 컴퓨터가 읽을수있는 html파일로 쪄버리기
            totla_page = soup.select('body > div.powerlink > div.content > ul.powerlink_list > li')


            for titl in totla_page:  # titles_by_select안에 titl가 있는동안 도라라
                link = titl.find('a',{'class':'tit'})
                f_url = link.get('href')
                te = link.text  # te안에 titl을 텍스트인것들(쇼핑몰 이름)을 담아라! 잘 담김=프린트해봄
                link2 = titl.find('div',{'class':'url_area'})
                te2 = link2.text # 보이는 url주소

                link3 = titl.find('div',{'class':'desc'})
                if link3:
                    te3 = link3.text

                else:
                    te3 =""

                link4 = titl.find('div',{'class':'period_area'})

                if link4:
                    te4 = link4.text
                else:
                    te4 = ""

                si = []
                link_2 = titl.find_all('a', 'menu_item_link')
                if link_2:
                    for i in link_2:
                        te_2 = i.text  # 이름
                        te_url = i.get('href')  # 주소
                        ei = {'url': te_url, 'tt': te_2}
                        si.append(ei)
                else:
                    si = ""


                img = titl.find('img')
                if  img:
                    iimg = img.get('src')#이미지가 있을 시 src뒤로붙은 주소가져오기
                else:
                    iimg = "None"


                try:
                    f_req = requests.get(f_url, headers=headers).text  #
                    cur = connection.cursor()
                    string = "select * from topic"
                    cur.execute(string)
                    see = cur.fetchall()
                    post1 = []
                    for t in see:  # 데이터베이스와 url 비교하는구문
                        if t[2] in f_req:
                            di = t[1]
                            post1.append(di)  #

                        dd = {'site': te,'f_url':f_url, 'title': post1, 'url': f_url,'te2':te2,'te3':te3,'te4':te4,'si':si,'iimg':iimg}
                except:
                    dd = {'site': te, 'f_url': f_url, 'title': '사이트 접속오류', 'url': f_url, 'te2': te2, 'te3': te3, 'te4': te4,
                          'si': si, 'iimg': iimg}
                    pass

                post.append(dd)



        if forms.is_valid():  # 폼 검증 #얘는 if request.method == 'POST': 안에 있어야 함
            return render(request, 'hello_app/m_key.html', {'form': forms, 'post': post})


    else:  # 얘는 if request.method == 'POST': 얘랑 짝꿍이라 if request.method == 'POST':쟤 줄에 같이있어야한다
        forms = Key2()
        return render(request, 'hello_app/m_key.html', {'form': forms, })  # 템플릿 파일 경로 지정, 데이터 전달










def key3(request):


    post = []  # 데이터베이스 안의 내용들이 한번씩 돌때마다 쌓여 담겨있어요 (포문안에쓰면 리셋되어 마지막꺼만 나옴)
    if request.method == 'POST':  # 포스트로 받은 값이 있다면
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36 Edge/14.14393'}

        forms = Key3(request.POST)  # HTTP가 인식하는 포스트의 모든값
        ke = forms.data['keyword3']  # POST안에 있는 키 값
        url = 'https://m.search.daum.net/search?w=ad&DA=PGD&q={}'.format(ke)  # 네이버 파워링크 url 뒤로 키워드값 넣기
        uurl = url + '&page={}'  # 페이지 수
        req = requests.get(url, headers=headers)  # 키워드넣은 값의 url을 갖고왔다
        html = req.text
        soup = BeautifulSoup(html, 'lxml')
        total = soup.select('body.daum')

        for at in total:
            art = at.text
            r = art.split('totalCount:')[1]
            d = r[1]+r[2]

            dew=int(d)
            gr = dew/10
            result = round(gr+1)

        for n in range(1,result):  # url페이지 수 100번 돌리기 포문
            u_url = uurl.format(n)  # url페이지 수 뒤로 n번만큼(100) 돌려라

            reqe = requests.get(u_url, headers=headers)  # 키워드넣은 값의 url을 갖고왔다

            html2 = reqe.text
            soup2 = BeautifulSoup(html2, 'lxml')
            titles_by_select = soup2.select(' #premiumLinkColl > div.coll_cont.cont_tab > ul > li')  # a태그 선택하여 titles_by_select안에 담아요


            for titl in titles_by_select:  # titles_by_select안에 titl가 있는동안 도라라
                link = titl.find('a',{'class':'wrap_tit'})
                te = link.text #사이트 이름
                f_url = link.get('href') #


                si = []
                link_2 = titl.find_all('a','f_link')
                if link_2:
                    for i in link_2:
                        te_2 = i.text #이름
                        te_url = i.get('href') #주소
                        ei = {'url':te_url,'tt':te_2}
                        si.append(ei)
                else:
                    si=""

                sub = titl.find('a',{'class':'wrap_sub'})
                if sub:
                    sub_text = sub.text
                    sub_url = sub.get('href')

                else:
                    sub_text = ""
                    sub_url = ""


                mid = titl.find('a',{'class':'desc f_db'})
                if mid:
                    mid_text = mid.text

                else:
                    mid_text = ""


                info = titl.find('a',{'class':'f_url txt_ellip'})
                if info:
                    info_text = info.text
                    info_url = info.get('href')

                else:
                    info_text = ""
                    info_url = ""






                kakaopay = titl.find('span',{'class':'ico_rwd ico_kakaopay'})
                if kakaopay:
                    kakao_p = kakaopay.text
                else:
                    kakao_p = ""



                tel = titl.find('a',{'class':'link_util'})
                if tel:
                    tel_p = tel.text
                else:
                    tel_p = ""




                img = titl.find('img',{'class':'thumb_img'})
                if  img:
                    iimg = img.get('src')#이미지가 있을 시 src뒤로붙은 주소가져오기
                else:
                    iimg = "None"

                try:
                    f_req = requests.get(f_url, headers=headers).text  #
                    cur = connection.cursor()
                    string = "select * from topic"
                    cur.execute(string)
                    see = cur.fetchall()
                    post1 = []
                    for t in see:  # 데이터베이스와 url 비교하는구문
                        if t[2] in f_req:
                            di = t[1]
                            post1.append(di) #

                    dd = {'site': te, 'title': post1, 'url': f_url,'si':si,'mid_text':mid_text,'info_text':info_text,'info_url':info_url,'sub_text':sub_text,'sub_url':sub_url,'iimg':iimg,'kakao_p':kakao_p,'tel_p':tel_p}


                except:
                    dd = {'site': te, 'title': '사이트 접속오류', 'url': f_url,'si':si,'mid_text':mid_text,'info_text':info_text,'info_url':info_url,'sub_text':sub_text,'sub_url':sub_url,'iimg':iimg,'kakao_p':kakao_p,'tel_p':tel_p}

                    pass

                post.append(dd)


        if forms.is_valid():  # 폼 검증 #얘는 if request.method == 'POST': 안에 있어야 함
            return render(request, 'hello_app/key3.html', {'form': forms, 'post': post})

    else:  # 얘는 if request.method == 'POST': 얘랑 짝꿍이라 if request.method == 'POST':쟤 줄에 같이있어야한다
        forms = Key3()
        return render(request, 'hello_app/key3.html', {'form': forms, })  # 템플릿 파일 경로 지정, 데이터 전달


from bs4 import BeautifulSoup
import requests
import time



try:
    f = 'http://newark.co.kr'
except FileNotFoundError:
    pass




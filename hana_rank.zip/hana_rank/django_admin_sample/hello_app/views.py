from django.shortcuts import render
from bs4 import BeautifulSoup
import requests
from django.http import HttpResponse
from .dict import song

def index2(request):
    return HttpResponse("헬로")
    




def index(request):  # key 라는 함수(그룹) 만들겠다고 def로 선언했어

    post = []  # 데이터베이스 안의 내용들이 한번씩 돌때마다 쌓여 담겨있어요 (포문안에쓰면 리셋되어 마지막꺼만 나옴)

    for i in song:


        url = 'https://search.naver.com/search.naver?where=kin&sm=tab_jum&query={}'.format(i['pw'])  # 키워드
        req = requests.get(url)

        if req.ok:
            html = req.text
            soup = BeautifulSoup(html, 'html.parser')
        titles_by_select = soup.select('ul.type01 > li > dl > dt > a')

        for title in titles_by_select:
            f_url = title.get('href')
            f_req = requests.get(f_url)
            f_html = f_req.text
            f_soup = BeautifulSoup(f_html, 'html.parser')
            see = f_soup.select('div.answer-content__list')

            for titl in see:
                bictitle = titl.find('div',{'class':'c-heading-answer__title'})
                tte = bictitle.find('span', {'class': 'people-relation people-relation--partner'})




                if i['id'] in bictitle.text:

                    r = f_url.split('&')
                    re = r[5]

                    dd = {'url': f_url, 'pw': i['pw'], 'id': i['id'], 're': re}
                    post.append(dd)





    return render(request, 'hello_app/main.html',{'post':post})

'''
if i['id'] in ti.text:  # 하나플랜론,#119,#렌트카

    r = f_url.split('&')
    re = r[5]

    dd = {'url': f_url, 'pw': i['pw'], 'id': i['id'], 're': re}
    post.append(dd)
    '''
